/**
 * Scientific Calculator - Techonet Assignment
 * Features: Basic + Scientific operations, Error handling, Input validation
 */

class Calculator {
    constructor() {
        this.expression = document.getElementById('expression');
        this.result = document.getElementById('result');
        this.currentInput = '';
        this.lastAnswer = 0;
        this.isScientific = false;
        this.init();
    }

    init() {
        // Button click events
        document.querySelectorAll('.btn').forEach(btn => {
            btn.addEventListener('click', () => this.handleInput(btn.dataset.value));
        });

        // Toggle scientific mode
        document.getElementById('toggle-mode').addEventListener('click', () => {
            this.isScientific = !this.isScientific;
            document.querySelector('.calculator').classList.toggle('scientific');
            document.getElementById('toggle-mode').textContent = 
                this.isScientific ? 'Basic' : 'Scientific';
        });

        // Keyboard support
        document.addEventListener('keydown', (e) => this.handleKeyboard(e));
    }

    handleInput(value) {
        try {
            switch(value) {
                case 'C':
                    this.clear();
                    break;
                case 'DEL':
                    this.delete();
                    break;
                case '=':
                    this.calculate();
                    break;
                case 'ANS':
                    this.currentInput += this.lastAnswer;
                    break;
                default:
                    this.appendValue(value);
            }
            this.updateDisplay();
        } catch (error) {
            this.showError(error.message);
        }
    }

    appendValue(value) {
        // Prevent multiple operators
        const operators = ['+', '-', '*', '/', '^', '%'];
        const lastChar = this.currentInput.slice(-1);
        
        if (operators.includes(value) && operators.includes(lastChar)) {
            this.currentInput = this.currentInput.slice(0, -1) + value;
            return;
        }

        // Prevent multiple decimals in same number
        if (value === '.') {
            const parts = this.currentInput.split(/[\+\-\*\/\^%\(\)]/);
            if (parts[parts.length - 1].includes('.')) return;
        }

        this.currentInput += value;
    }

    clear() {
        this.currentInput = '';
        this.result.value = '0';
    }

    delete() {
        this.currentInput = this.currentInput.slice(0, -1);
    }

    calculate() {
        if (!this.currentInput) throw new Error('Empty input');
        
        let expr = this.currentInput
            .replace(/π/g, 'Math.PI')
            .replace(/e/g, 'Math.E')
            .replace(/sin\(/g, 'Math.sin(')
            .replace(/cos\(/g, 'Math.cos(')
            .replace(/tan\(/g, 'Math.tan(')
            .replace(/log\(/g, 'Math.log10(')
            .replace(/ln\(/g, 'Math.log(')
            .replace(/sqrt\(/g, 'Math.sqrt(')
            .replace(/abs\(/g, 'Math.abs(')
            .replace(/\^/g, '**')
            .replace(/(\d+)!/g, (match, num) => this.factorial(parseInt(num)));

        // Validation checks
        this.validateExpression(expr);

        // Handle 1/x
        expr = expr.replace(/1\/(\d+\.?\d*)/g, '(1/$1)');

        let answer = Function('"use strict"; return (' + expr + ')')();
        
        // Handle errors
        if (!isFinite(answer)) throw new Error('Math Error');
        if (isNaN(answer)) throw new Error('Invalid Expression');

        // Round to avoid floating point issues
        answer = parseFloat(answer.toFixed(10));
        
        this.lastAnswer = answer;
        this.result.value = answer;
        this.currentInput = answer.toString();
    }

    validateExpression(expr) {
        // Division by zero
        if (/\/0(?!\d)/.test(expr)) throw new Error('Division by zero');
        
        // Square root of negative
        if (/Math\.sqrt\(-/.test(expr)) throw new Error('Invalid sqrt input');
        
        // Invalid characters
        if (/[^0-9+\-*/.() MathPIEsincotalgqrtb]/.test(expr)) {
            throw new Error('Invalid characters');
        }

        // Mismatched parentheses
        const open = (expr.match(/\(/g) || []).length;
        const close = (expr.match(/\)/g) || []).length;
        if (open !== close) throw new Error('Mismatched parentheses');
    }

    factorial(n) {
        if (n < 0) throw new Error('Factorial of negative');
        if (n > 170) throw new Error('Number overflow');
        if (!Number.isInteger(n)) throw new Error('Factorial of decimal');
        if (n === 0 || n === 1) return 1;
        let result = 1;
        for (let i = 2; i <= n; i++) result *= i;
        return result;
    }

    showError(msg) {
        this.result.value = msg;
        setTimeout(() => {
            this.result.value = this.lastAnswer || '0';
        }, 1500);
    }

    updateDisplay() {
        this.expression.value = this.currentInput || '0';
    }

    handleKeyboard(e) {
        const key = e.key;
        if (/[0-9+\-*/.()]/.test(key)) this.handleInput(key);
        else if (key === 'Enter') this.handleInput('=');
        else if (key === 'Backspace') this.handleInput('DEL');
        else if (key === 'Escape') this.handleInput('C');
    }
}

// Initialize calculator
new Calculator();